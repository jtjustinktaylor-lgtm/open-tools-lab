# Field Kit

Three pilots by Open Tools Studio:

- **LastSlot:** Any appointment business can post one opening with optional provider, duration, price in CAD and booking requirements. The first eligible customer to confirm gets the slot and a private confirmation. The business sees the customer's contact information on its private manager page and handles payment and follow-up directly.
- **BorrowBoard:** A club adds items, downloads an item QR label, and sets the loan period. Members check themselves out from the item page and get a due date. The gear manager records returns and sees overdue loans and can search and filter inventory.
- **RainPlan:** An organizer shares an event link and publishes status, venue, or time changes, with an optional pinned announcement. The public page refreshes periodically while open, and shows earlier updates.

## Try it or run it

The static browser preview stores fictional trial data in the current browser. It doesn't synchronize with other phones. Use generic sample info in the preview.

For shared boards, use Node 24+ and run `npm test` then `npm start`. Open http://127.0.0.1:8433/. The shared server saves boards in SQLite and separates public links, private manager links, and private receipts. No install step.

For a cross-device pilot, deploy the Dockerfile on a Node container host with a persistent volume at `/app/data` and HTTPS. Set `PUBLIC_ORIGIN` to the exact origin, e.g. `https://fieldkit.example.com`, and set `PORT=8433` if your host needs it. Back up the SQLite volume. Run one instance for the pilot. Save manager links somewhere private; this version does not have account recovery. The pilots do not send reminders, contact customers, or handle payments.

Start with a grooming cancellation, one club's gear checkout, or a league's next change. Track whether the participant finishes without help and whether the organizer uses the same product a second time.

The QR generator is vendored under its original license in `public/qr-license.txt`.
